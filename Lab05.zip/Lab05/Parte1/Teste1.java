public class Teste1{
	public static void main(String args[]){	
		Operand operand1 = new Operand(7);
		Operand operand2 = new Operand(5);
		Operand operand3 = new Operand(6);
		Multiply multiply = new Multiply();
		multiply.Add(operand1);
		multiply.Add(operand2);
		multiply.Remove();
		multiply.Add(operand3);
		System.out.println(multiply.Operation());
	}	

}
