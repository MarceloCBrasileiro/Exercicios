abstract class Expression {
	Operand esq, dir;
	

	abstract float Operation();

	void Add(Operand x){
		if(this.esq == null)
			this.esq = x;
		else
			this.dir = x;
	}

	void Remove() {
		if(this.dir == null)
			this.esq = null;
		else
			this.dir = null;
	}

}

class Operand extends Expression{
	float operando;
	Operand(float x) {
		this.operando = x;
	}
	float Operation() {
		return this.operando;
	}
	void mudarValor(float x) {
		this.operando = x;
	}
}

abstract class Operator extends Expression {

	abstract float Operation();	

}

class Multiply extends Operator {
	

	float Operation() {
		return this.esq.Operation()*this.dir.Operation();
	}
}

class Divide extends Operator {


	float Operation() {
		return this.esq.Operation()/this.dir.Operation();
	}
}


