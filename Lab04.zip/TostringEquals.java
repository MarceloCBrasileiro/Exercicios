abstract class TostringEquals{
	public abstract String  toString();
	public abstract boolean equals(Object figura2);



}