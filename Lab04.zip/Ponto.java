class Ponto {
	float x;
	float y;
	Ponto(float x, float y){
		this.x = x;
		this.y = y;
	}
	void moverPonto(float dx,float dy){
		this.x +=dx;
		this.y +=dy;
	}
	float getX(){
		return this.x;
	}
	float getY(){
		return this.y;
	}
	public boolean equals(Object obj) {
	if ( (obj instanceof Ponto)){ 
		if(((Ponto) obj).x==this.x && ((Ponto) obj).y==this.y){
			return true;
		}else{
			return false;
		}


	} else {
		return false;
	}
}	
	String toString2(){
		return "("+this.x+","+this.y+")";

	}

	public void apagarPonto(){
		this.x=0;
		this.y=0;
	
	}
}