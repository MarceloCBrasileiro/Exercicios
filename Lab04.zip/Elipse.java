public class Elipse extends TostringEquals implements Figura {

	private Ponto foco1;
	private Ponto foco2;
	private Ponto centro;
	private float distfocal,eixomaior,eixomenor,excentricidade,a,b,c;

	public String Desenhar() {
		
		return this.toString();
	
	}
// POLIMORFISMO DE SOBRECARGA -> CONSTRUTORES //
	Elipse(){
		this.b=0;
		this.c=0;
		this.a = (b*b)+(c*c);
		Ponto cen = new Ponto(0,0);
		this.centro = cen;
		this.foco1 = cen;
		this.foco2 = cen;
		this.distfocal = 2 * c;
		this.eixomaior = 2 * a;
		this.eixomenor = 2 * b;
		this.excentricidade = c / a;
	}


	Elipse(float b, float c, Ponto x){
		this.b = b;
		this.c = c;
		this.a = (b*b)+(c*c);
		this.centro = x;
		this.foco1 = new Ponto(x.x-c,x.y);
		this.foco2 = new Ponto(x.x-c,x.y);
		this.distfocal = 2 * c;
		this.eixomaior = 2 * a;
		this.eixomenor = 2 * b;
		this.excentricidade = c / a;

	}


	public Ponto getFoco1(){
		return this.foco1;
	}
	public Ponto getFoco2(){
		return this.foco2;
	}
	public Ponto getCentro(){
		return this.centro;
	}
	public float getEixomaior(){

        return this.eixomaior;
    }
    public float getEixomenor(){

        return this.eixomenor;
    }
   

	public double CalcularArea() {

		return (this.a * this.b * Math.PI);
	}

	public void mover(float dx, float dy) {
        
        this.centro.moverPonto(dx, dy);
        this.foco1.moverPonto(dx,dy);
        this.foco2.moverPonto(dx,dy);
    
    }

     public void Redimensionar(float x){
    	
    	this.c=c+x;
    	this.b=b+x;
    
    }


    public void Apagar(){

    	this.b = 0;
		this.c = 0;
		this.a = (b*b)+(c*c);
		this.centro.apagarPonto();
		this.foco1.apagarPonto();
		this.foco2.apagarPonto();
		this.distfocal = 2 * c;
		this.eixomaior = 2 * a;
		this.eixomenor = 2 * b;
		this.excentricidade = 0;
    
    }

    public double CalcularPerimetro(){

    	return (2*Math.PI)*(Math.sqrt((this.eixomaior*this.eixomaior)+(this.eixomenor*this.eixomenor)/2));
    
    }

    public String toString(){
    	
    	return "Elipse" + " de centro " + this.centro.toString2() + ", focos " + this.foco1.toString2() + this.foco2.toString2() + ", eixo maior " + this.eixomaior + ", eixo menor " + this.eixomenor + ", com distancia focal de " + this.distfocal + " e excentricidade " + this.excentricidade;
	
	}

	public boolean equals(Object obj){
		if(obj instanceof Elipse){
			Elipse aux = (Elipse)obj;
			if (this.foco1.equals(aux.getFoco1()) &&  this.foco2.equals(aux.getFoco2()) && this.centro.equals(aux.getCentro()) && this.eixomaior == aux.eixomaior && this.eixomenor == aux.eixomenor){
					return true;
			}else { 
				return false; 
				}
		}else{
			return false;
		}	
	}
}