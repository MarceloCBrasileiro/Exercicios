public interface Figura{
	
	String Desenhar();
	void mover(float dx, float dy);
	double CalcularArea();
	String  toString();
	boolean equals(Object figura2);
	void Redimensionar(float tamanho);
	double CalcularPerimetro();

}