
//POLIMORFISMO DE INCLUSAO DA CLASSE TOSTRINGEQUALS EM QUADRADO//
public class Quadrado extends TostringEquals implements Figura{
	float lado;
	Ponto ponto1;
	Ponto ponto2;
	Ponto ponto3;
	Ponto ponto4;
	
	
	Quadrado(float lado){
		this.ponto1 = new Ponto(0,0);
		this.ponto2 = new Ponto(0,lado);
		this.ponto3 = new Ponto(lado,0);
		this.ponto4 = new Ponto(lado,lado);
	
		this.lado = lado;
		
	}
	public void Redimensionar(float tamanho){
		this.lado+=tamanho;
	    this.ponto2.moverPonto(0,tamanho);
		this.ponto3.moverPonto(tamanho,0);
		this.ponto4.moverPonto(tamanho,tamanho);	



	}
	public void mover(float dx, float dy){
		this.ponto1.moverPonto(dx,dy);
		this.ponto2.moverPonto(dx,dy);
		this.ponto3.moverPonto(dx,dy);
		this.ponto4.moverPonto(dx,dy);
		
	
	}
	public double CalcularArea(){
		return this.lado*this.lado;
	}
	
	public String Desenhar(){
	
		return this.toString();

	}

	public String toString(){
		String string;
		string = "Quadrado de lado: "+this.lado + " e Pontos: "+this.ponto1.toString2()+","+this.ponto2.toString2()+","+this.ponto3.toString2()+","+this.ponto4.toString2(); 
		return string;
	}
	
	
	public boolean equals(Object obj){
		if(obj instanceof Quadrado){
	        Quadrado aux = (Quadrado)obj;
	        if ( (this.lado==aux.lado) && (this.ponto1.equals(aux.ponto1)) && (this.ponto2.equals(aux.ponto2)) && (this.ponto3.equals(aux.ponto3)) &&  (this.ponto4.equals(aux.ponto4)) ){
	            return true;
	        } else { return false; }
    	}else{
    		return false;
    	}
	}
	public double CalcularPerimetro(){
		return lado*4;

	}
   

}
