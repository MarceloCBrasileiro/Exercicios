class Editor{

	public static void main(String[] args){
		Ponto ponto1= new Ponto(10,20);
		Editor editor= new Editor();
		//CRIANDO QUADRADO//
		//VARIOS EXEMPLOS SEGUIDOS DE POLIMORFISMO DE COERÇÃO AO CONVERTER INTEIRO PARA FLOAT//
		editor.criarQuadrado(15);
		//CRIANDO QUADRADO2//
	
		editor.criarQuadrado(25);
		//CRIANDO TRIANGULO//
		
		editor.criarTriangulo(10,15,20,ponto1);
		//CRIANDO ELIPSE//
		
		editor.criarElipse(10,20,ponto1);
		//CRIANDO CIRCULO//
		
		editor.criarCirculo(ponto1,10);
		

		//REDIMENSIONANDO O CIRCULO//
		editor.Redimensionar(editor.vetfig[4],5);
		

		//APAGANDO A ELIPSE CRIADA//
		editor.Apagar(editor.vetfig[3]);
		//QUADRADO SUBSTITUI O LUGAR DA ELIPSE//
		editor.criarQuadrado(5);

		//MOVENDO O TRIANGULO//
		editor.mover(editor.vetfig[2],2,2);

		//CALCULANDO O PERIMETRO DO QUADRADO 1//
		System.out.println(editor.CalcularPerimetro(editor.vetfig[0]));
		
		//CALCULANDO O PERIMETRO DO QUADRADO QUE SUBSTITUIU A ELIPSE.//
		System.out.println(editor.CalcularPerimetro(editor.vetfig[3]));

		//CALCULANDO AREA DO CIRCULO//
		System.out.println(editor.CalcularArea(editor.vetfig[4]));

		//MOSTRANDO ELEMENTOS DO VETOR//
		editor.ShowElementos();



	}
	Figura vetfig[]= new Figura[50];
	
	void criarQuadrado(float lado){
		Quadrado quadrado= new Quadrado(lado);
		boolean cheio= true;
		for(int i=0;i<50;i++){
			if(this.vetfig[i]==null){
				this.vetfig[i]= quadrado;
				i=50;
				cheio = false;

			}

		}
		if (cheio==true){
			System.out.println("vetor cheio");
		}
		
	}
	void criarTriangulo(float lado1, float base, float lado2, Ponto x){
		Triangulo triangulo= new Triangulo(lado1,base,lado2,x);
		boolean cheio= true;
		for(int i=0;i<50;i++){
			if(this.vetfig[i]==null){
				this.vetfig[i]= triangulo;
				i=50;
				cheio = false;

			}

		}
		if (cheio==true){
			System.out.println("vetor cheio");
		}
	}
	void criarElipse(float b, float c, Ponto x){
		Elipse elipse= new Elipse(b,c,x);
		boolean cheio= true;
		for(int i=0;i<50;i++){
			if(this.vetfig[i]==null){
				this.vetfig[i]= elipse;
				i=50;
				cheio = false;

			}

		}
		if (cheio==true){
			System.out.println("vetor cheio");
		}
	}
	void criarCirculo(Ponto centro, float raio){
		Circulo circulo= new Circulo(centro,raio);
		boolean cheio= true;
		for(int i=0;i<50;i++){
			if(this.vetfig[i]==null){
				this.vetfig[i]= circulo;
				i=50;
				cheio = false;

			}

		}
		if (cheio==true){
			System.out.println("vetor cheio");
		}
	}
	String Desenhar(Figura figura){
		
		for(int i=0;i<50;i++){
			if(this.vetfig[i]==figura){
				return this.vetfig[i].Desenhar();
				
				

			}

		}
		
		System.out.println("Essa figura não pertence ao vetor coleção");
		return null;
	}	

	
	void Apagar(Figura figura){
		boolean achou= false;
		for(int i=0;i<50;i++){
			if(this.vetfig[i]==figura){
				this.vetfig[i]=null;
				i=50;
				achou=true;

			}

		}
		if (achou==false){
			System.out.println("Essa figura não pertence ao vetor coleção");
		}

		

	}
	void mover(Figura figura,float dx, float dy){
		boolean achou= false;
		for(int i=0;i<50;i++){
			if(this.vetfig[i]==figura){
				this.vetfig[i].mover(dx,dy);
				i=50;
				achou=true;

			}

		}
		if (achou=false){
			System.out.println("Essa figura não pertence ao vetor coleção");
		}
		

	}
	void Redimensionar(Figura figura, float tamanho){
		boolean achou= false;
		for(int i=0;i<50;i++){
			if(this.vetfig[i]==figura){
				this.vetfig[i].Redimensionar(tamanho);
				i=50;
				achou=true;

			}

		}
		if (achou=false){
			System.out.println("Essa figura não pertence ao vetor coleção");
		}
	}
	double CalcularArea(Figura figura){
		
		for(int i=0;i<50;i++){
			if(this.vetfig[i]==figura){
				return this.vetfig[i].CalcularArea();
				
			

			}

		}
		
		System.out.println("Essa figura não pertence ao vetor coleção");
		return 0;
	}	

	
	double CalcularPerimetro(Figura figura){
		boolean achou= false;
		for(int i=0;i<50;i++){
			if(this.vetfig[i]==figura){
				return this.vetfig[i].CalcularPerimetro();	
			}

		}
		
		System.out.println("Essa figura não pertence ao vetor coleção");
		return 0;
	}
	void ShowElementos(){
		for(int i=0;i<50;i++){
			if(this.vetfig[i]!=null){
				System.out.println(this.Desenhar(this.vetfig[i]));
			}

		}

	}
}