public class Circulo extends TostringEquals implements Figura{
	float raio;
	
	Ponto centro;
	
	
	Circulo(Ponto centro, float raio){
		this.centro = centro;
		this.raio = raio;
	
		
	}
    public Ponto getCentro(){

        return this.centro;
    }
    public float getRaio(){

        return this.raio;
    }

	
	public void Redimensionar(float raio){

		this.raio += raio;
	}
	public void mover(float dx, float dy){
		this.centro.moverPonto(dx,dy);
	
	}
	public double CalcularArea(){
		return ((float) Math.PI)*(raio*raio);
	}
	public String Desenhar(){
		return this.toString();

	}
	
	public String toString(){
		String string;
		string = "Circulo de Raio : "+this.raio+" , com o Centro : x="+this.centro.getX() + " y=" +this.centro.getY(); 
		return string;
	}


	public boolean equals(Object obj){
		if(obj instanceof Circulo){
	        Circulo aux = (Circulo)obj;
	        if ((this.centro.equals(aux.getCentro())) && (this.raio == aux.raio)){
	            return true;
	        } else { return false; }
    	}else{
    		return false;
    	}
    }


	public double CalcularPerimetro(){
		return 2*Math.PI*this.raio;

	}
}